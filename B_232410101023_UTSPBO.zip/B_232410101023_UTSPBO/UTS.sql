CREATE TABLE kontak(
	nama Varchar(10) NOT NULL,
	Email Varchar (20) NOT NULL,
	no_Hp Varchar (12) NOT NULL
);

insert into kontak (nama, email, no_Hp) values
('karin', 'Karin14@gmail.com', 0812345678);


select * from kontak