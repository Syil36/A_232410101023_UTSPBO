﻿namespace B_232410101023_utspbo.View
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            textUsername = new Label();
            textPassword = new Label();
            textBox2 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(268, 46);
            label1.Name = "label1";
            label1.Size = new Size(211, 34);
            label1.TabIndex = 0;
            label1.Text = "Selamat Datang!";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(174, 172);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(373, 27);
            textBox1.TabIndex = 1;
            // 
            // textUsername
            // 
            textUsername.AutoSize = true;
            textUsername.Location = new Point(174, 149);
            textUsername.Name = "textUsername";
            textUsername.Size = new Size(75, 20);
            textUsername.TabIndex = 2;
            textUsername.Text = "Username";
            // 
            // textPassword
            // 
            textPassword.AutoSize = true;
            textPassword.Location = new Point(174, 217);
            textPassword.Name = "textPassword";
            textPassword.Size = new Size(70, 20);
            textPassword.TabIndex = 3;
            textPassword.Text = "Password";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(174, 240);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(373, 27);
            textBox2.TabIndex = 4;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 192, 192);
            button1.Location = new Point(283, 315);
            button1.Name = "button1";
            button1.Size = new Size(129, 41);
            button1.TabIndex = 5;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(textPassword);
            Controls.Add(textUsername);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Login";
            Text = "Login";
            Load += Login_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private Label textUsername;
        private Label textPassword;
        private TextBox textBox2;
        private Button button1;
    }
}