﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace B_232410101023_utspbo.View
{
    public partial class Login : Form
    {
        private string connectionstring = "Host=localhost;Port=5432;Username=postgres;Password=syil36;Database=kodeA";
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Username = textBox1.Text;
            string Password = textBox2.Text;

            if (ValidateLogin(Username, Password))
            {
                Dashboard dashboard = new Dashboard();
                dashboard.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username atau Password salah", "Login Gagal", MessageBoxButton);
            }
        }
    }
}
